import java.util.Arrays;

import board_elements.BoardMatrix;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepsDefinitionBoard {
	
	BoardMatrix bmatrix = new BoardMatrix();
	
	
	@Given("a matrix with {int} rows and {int} columns")
	public void a_matrix_with_rows_and_columns(Integer int1, Integer int2) {
		bmatrix.setMatrix(int1,int2);
	    
	}
	@When("the user runs the script")
	public void the_user_runs_the_script() {
	    bmatrix.isRunning(true);
	}
	@Then("A window opens with the shown matrix with {int} rows and {int} columns")
	public void a_window_opens_with_the_shown_matrix_with_rows_and_columns(Integer int1, Integer int2) {
		System.out.println(Arrays.deepToString(bmatrix.getMatrix(int1, int2)));
	}

}
