package board_elements;

public class BoardMatrix {
	
	private int rows;
	private int columns;
	
	private boolean runBoard;
	
	public void setMatrix(int rows, int columns) {
		int[][] matrix = new int [rows][columns];
		
	}
	public int[][] getMatrix(int rows, int columns) {
		int[][] matrix = new int[rows][columns];
		return matrix;
	}
	
	
	public void isRunning(boolean runBoard) {
		this.runBoard = runBoard;
		
	}
}
